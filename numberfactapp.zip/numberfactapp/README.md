# NUM
app with interesting facts about numbers

on google play: https://play.google.com/store/apps/details?id=com.aida.numberfact
