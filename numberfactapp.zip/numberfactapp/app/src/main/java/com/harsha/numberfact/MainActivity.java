package com.harsha.numberfact;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Date;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    private final String TAG="mainActivity";

    TextView output,desc;
    EditText input;
    Button search,number,date;
    ImageView twitter,facebook;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ActionBar mActionBar = getSupportActionBar();
        mActionBar.setDisplayOptions( ActionBar.DISPLAY_SHOW_HOME |ActionBar.DISPLAY_SHOW_TITLE);

        output=(TextView)findViewById(R.id.output);
        input=(EditText) findViewById(R.id.input);
        twitter=(ImageView)findViewById(R.id.twitter);
        facebook=(ImageView)findViewById(R.id.facebook);
        search=(Button)findViewById(R.id.search);



        input.setOnClickListener(this);
        search.setOnClickListener(this);
        twitter.setOnClickListener(this);
        facebook.setOnClickListener(this);



        input.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_DOWN) {
                    switch (keyCode) {
                        case KeyEvent.KEYCODE_DPAD_CENTER:
                        case KeyEvent.KEYCODE_ENTER:

                            String number = input.getText().toString();
                            if (number.equals("")) {
                                Toast.makeText(getApplicationContext(), "Enter number", Toast.LENGTH_LONG).show();

                            } else {
                                InputMethodManager inputManager =
                                        (InputMethodManager) getApplicationContext().
                                                getSystemService(Context.INPUT_METHOD_SERVICE);
                                inputManager.hideSoftInputFromWindow(
                                        MainActivity.this.getCurrentFocus().getWindowToken(),
                                        InputMethodManager.HIDE_NOT_ALWAYS);
                                int num = Integer.parseInt(number);
                                MyAsyncTask me = new MyAsyncTask();
                                me.execute(Constants.BASE_URL + num + Constants.BASE_JSON);


                            }

                            return true;
                        default:
                            break;
                    }
                }
                return false;
            }
        });

//


    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){

            case R.id.search:

                String number = input.getText().toString();
                if (number.equals("")) {
                    Toast.makeText(getApplicationContext(), "Enter number", Toast.LENGTH_LONG).show();

                } else {
                    InputMethodManager inputManager =
                            (InputMethodManager) this.
                                    getSystemService(Context.INPUT_METHOD_SERVICE);
                    inputManager.hideSoftInputFromWindow(
                            this.getCurrentFocus().getWindowToken(),
                            InputMethodManager.HIDE_NOT_ALWAYS);
                    int num = Integer.parseInt(number);
                    MyAsyncTask me = new MyAsyncTask();
                    me.execute(Constants.BASE_URL + num + Constants.BASE_JSON);

                }
                break;
            case R.id.twitter:
                String userEntry = output.getText().toString()+"https://play.google.com/store/apps/details?id=com.aida.numberfact";

                Intent tweetIntent = new Intent(Intent.ACTION_SEND);
                tweetIntent.putExtra(Intent.EXTRA_TEXT, userEntry);
                tweetIntent.setType("text/plain");

                PackageManager packManager = getPackageManager();
                List<ResolveInfo> resolvedInfoList = packManager.queryIntentActivities(tweetIntent, PackageManager.MATCH_DEFAULT_ONLY);

                boolean resolved = false;
                for (ResolveInfo resolveInfo : resolvedInfoList) {
                    if (resolveInfo.activityInfo.packageName.startsWith("com.twitter.android")) {
                        tweetIntent.setClassName(
                                resolveInfo.activityInfo.packageName,
                                resolveInfo.activityInfo.name);
                        resolved = true;
                        break;
                    }
                }
                if (resolved) {
                    startActivity(tweetIntent);
                } else {
                    Intent i = new Intent();
                    i.putExtra(Intent.EXTRA_TEXT, userEntry );
                    i.setAction(Intent.ACTION_VIEW);
                    i.setData(Uri.parse("https://twitter.com/intent/tweet?text=message&via=profileName"));
                    startActivity(i);
                    Toast.makeText(getApplicationContext(), "Twitter app isn't found", Toast.LENGTH_LONG).show();
                }
                break;
            case R.id.facebook:
                String userEntry1 = output.getText().toString() + "https://play.google.com/store/apps/details?id=com.aida.numberfact";

                try {
                    Intent intent1 = new Intent();
                    intent1.setClassName("com.facebook.katana", "com.facebook.katana.activity.composer.ImplicitShareIntentHandler");
                    intent1.setAction("android.intent.action.SEND");
                    intent1.setType("text/plain");
                    intent1.putExtra("android.intent.extra.TEXT", userEntry1);
                    startActivity(intent1);
                } catch (Exception e) {
                    // If we failed (not native FB app installed), try share through SEND
                    Intent intent = new Intent(Intent.ACTION_SEND);
                    String sharerUrl = "https://www.facebook.com/sharer/sharer.php?u=" + userEntry1;
                    intent = new Intent(Intent.ACTION_VIEW, Uri.parse(sharerUrl));
                    startActivity(intent);
                }
                break;


        }
    }

    public class MyAsyncTask extends AsyncTask<String, String, String> {
        /**this method is background task called not to block main UI thread.Data gets retrieved in this method */
        @Override
        protected String doInBackground(String... params) {
            Log.v(TAG, "string params from background: " + params.toString());

            try {
                //implementing network call using httpUrlConnection
                URL url = new URL(params[0]);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();

               // connection.addRequestProperty("User-Agent", "AidaIssayeva");

                //reading text from a character-input stream, buffering characters so as to provide for the efficient reading of array
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuffer json = new StringBuffer(1024);
                String tmp = "";
                while ((tmp = reader.readLine()) != null)
                    json.append(tmp).append("\n");
                reader.close();


                return json.toString();
            }catch (Exception e){
                e.printStackTrace();
            }
            return null;

        }

        /**method called to apply data from doInBackground method to main UI  */
        protected void onPostExecute(String result) {

            Log.v(TAG, "JSON Raw Data: " + result);

            try {
                Gson gson=new Gson();
                NumberFact numberFact=gson.fromJson(result,NumberFact.class);
                if(numberFact.getFound()) {
                    output.setText(numberFact.getText());
                    input.setText("");
                }else{
                    output.setText("There are no facts about "+ input.getText().toString());
                    input.setText("");
                }



            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

}
