package com.aida.numberfact;

import com.google.gson.annotations.SerializedName;

/**
 * Created by AIDA on 4/15/16.
 */
public class NumberFact {
    @SerializedName("text")
    private String text;

    @SerializedName("found")
    private boolean found;

    @SerializedName("number")
    private float number;

    @SerializedName("type")
    private String type;

    @SerializedName("date")
    private String date;

    @SerializedName("year")
    private String year;

    public float getNumber(){
        return number;
    }
    public void setNumber(Float number){
        this.number=number;
    }

    public String getText(){
        return text;
    }
    public void setText(String text){
        this.text=text;
    }
    public boolean getFound(){
        return found;
    }
    public void setFound(Boolean found){
        this.found=found;
    }
}
