package com.aida.numberfact;

/**
 *
 *
 * http://numbersapi.com/number/type
 *
 * type is one of trivia, math, date, or year. Defaults to trivia if omitted.
 * number is
 an integer, or
 the keyword random, for which we will try to return a random available fact, or
 a day of year in the form month/day (eg. 2/29, 1/09, 04/1), if type is date
 ranges of numbers
 */

public class Constants {

    public static String BASE_URL="http://numbersapi.com/";
    public static String BASE_JSON="?json";
    public static String YEAR="/year";
    public static String RANDOM="random";
    public static String MATH="/math";
    public static String TRIVIA="/trivia";


}
